#### sadiat ibrahim
### CSC 132
### Fractal class







    

MIN_X = 5
MAX_X = 595
MIN_Y = 5
MAX_Y = 515



class Fractal(object):
    def __init__(self, dimensions):
        self.dimensions = dimensions
        self.num_points = 50000
        self.r = 0.5
        self.vertex = []

    def frac_x(self, r):
        return int((self.dimensions[MAX_X] - \
                    self.dimensions[MIN_X]) * self.r) + \
                    self.dimensions[MIN_X]

    def frac_y(self, r):
        return int((self.dimensions[MAX_X] - \
                    self.dimensions[MIN_X]) * r) + \
                    self.dimensions[MIN_X]



## creates the Sierpinski triangle
class SierpinskiTriangle(Fractal):
    def __init__(self, dimensions):
        Fractal.__init__(self, dimensions)


## class that creates the carpet
class SierpinskiCarpet(Fractal):
    def __init__(self, dimensions):
        Fractal.__init__(self, dimensions)
        self.r = 0.66
        self.num_points = 100000

## class that creates the hexagon
class Hexagon(Fractal):
    def __init__(self, dimensions):
        Fractal.__init__(self, dimensions)
        self.r = 0.665
        self.num_points = 50000
    
